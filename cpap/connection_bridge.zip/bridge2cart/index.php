<?php
header('Location: ../', true, 302);